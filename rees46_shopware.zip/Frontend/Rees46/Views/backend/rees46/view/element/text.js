Ext.define('Shopware.apps.Rees46.view.element.Text', {
    extend: 'Ext.form.field.Text',
    alias: [
        'widget.element-text',
        'widget.element-textfield'
    ]
});
