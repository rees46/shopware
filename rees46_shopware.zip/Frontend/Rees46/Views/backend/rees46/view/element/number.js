Ext.define('Shopware.apps.Rees46.view.element.Number', {
    extend: 'Ext.form.field.Number',
    alias: [
        'widget.element-number',
        'widget.element-numberfield'
    ],
    submitLocaleSeparator: false
});
